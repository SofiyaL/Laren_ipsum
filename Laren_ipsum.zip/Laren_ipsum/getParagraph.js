document.getElementById('btn').addEventListener('click',()=>{
    var inputValue=document.getElementById('txt').value;
    generatePara(inputValue);

})
function generatePara(inputValue){
    var rand="Good developer is an artist, a craftsman who enjoys the process of creation. "+
    " rsa rsa rsa jhgfgh dghjdfg jkfhflg fgfdhj fjgjdf tjt yd xvs ddsfg,sf dfgdfg."+
    " Gsdf dfgd ergdf rth dfbdfb rdgd fgdghdh dgr thd Gsfg sdf kjfhd kjhgdk kfdgkfdhg jfjdsk.";
     
    document.getElementById("paragraph").innerHTML="";   
    document.getElementById("paragraphDiv").style.boxShadow= "0px 2px 15px black"; 
        for(let i=1; i<=inputValue;i++){
             
            document.getElementById('paragraph').innerHTML += "<br/>"+i+"."+"<br>"+rand;
            
        }
    console.log(inputValue);
    console.log(rand);
}
